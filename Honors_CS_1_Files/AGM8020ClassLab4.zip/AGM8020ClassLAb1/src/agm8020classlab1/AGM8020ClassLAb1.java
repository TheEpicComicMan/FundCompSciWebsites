/*
 *	To	change this	license header, choose License Headers	in	Project Properties.
 *	To	change this	template	file,	choose Tools |	Templates
 *	and open	the template in the editor.
 */
package agm8020classlab1;

import java.util.Arrays;

/**
 *
 * @author agm8020
 *
 * Anthony Migyanka
 *
 *
 */
public class AGM8020ClassLAb1 {

    /**
     * @param args the command line	arguments
     */
    public static void main(String[] args) {

        Student[] student = new Student[32];
        

        for (int i = 0; i < student.length; i++) {
            student[i] = new Student();
        }
        Student[] round1 = playRound(student);
        printArray(round1, 1);
        Student[] round2 = playRound(round1);
        printArray(round2, 2);
        Student[] round3 = playRound(round2);
        printArray(round3 ,3);
        Student[] round4 = playRound(round3);
        printArray(round4, 4);
        Student[] winner = playRound(round4);
        System.out.println("The winner is: " + winner[0].getName());

    }

    public static void printArray(Student[] array, int round) {
        System.out.print("Round " + round + ": ");
        for (int i = 0; i < array.length; i++) {
            if (i != array.length - 1) {
                System.out.print(array[i].getName() + ", ");
            } else {
                System.out.println(array[i].getName());
            }
        }
    }

    public static Student[] playRound(Student[] student) {
        int index = 0;
        Student[] nextRound = new Student[student.length / 2];
        for (int i = 0; i < student.length; i += 2) {
            String one = "";
            String two = "";
            while (one.equals(two)) {
                one = student[i].playRPS();
                two = student[i + 1].playRPS();
            }
            String result = compare(one, two);
            if (result.equals("one")) {
                nextRound[index] = student[i];
            } else {
                nextRound[index] = student[i + 1];
            }
            index++;

        }
        return nextRound;
    }

    public static String compare(String one, String two) {
        String winner;
        if (one.equals("rock")) {
            if (two.equals("paper")) {
                winner = "two";
            } else {
                winner = "one";
            }
        } else if (one.equals("paper")) {
            if (two.equals("scissors")) {
                winner = "two";
            } else {
                winner = "one";
            }
        } else {
            if (two.equals("rock")) {
                winner = "two";
            } else {
                winner = "one";
            }
        }
        return winner;
    }
}
