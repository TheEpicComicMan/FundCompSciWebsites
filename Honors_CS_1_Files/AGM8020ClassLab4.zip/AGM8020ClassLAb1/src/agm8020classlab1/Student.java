/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agm8020classlab1;

import java.util.Arrays;

/**
 *
 * @author agm8020
 * 
 * Anthony Migyanka
 */
public class Student {

    private String firstName;
    private String lastName;
    private int studentID;
    private int gradeLevel;
    private int[] exams;
    
    public Student (){
        firstName = randomName();
        lastName = randomName();
        studentID = (int)(Math.random()*90000+10000);
        gradeLevel = (int)(Math.random()*4+9);
    }
    public Student(String first, String last, int id, int grade) {
        firstName = first;
        lastName = last;
        studentID = id;
        gradeLevel = grade;
    }
    public static String randomName(){
        String name = "";
        
        // first letter is caps
        name += (char) randomNumber(65, 90);
        int num = randomNumber(4,8);
        // rest of first name
        for(int i = 0; i < num; i++){
            name += (char) randomNumber(97, 122);
        }
        
        return name;
    }
    public void takeExam() {
        int score = (int) (Math.random() * 30 + 70);
        if (exams == null) {
            exams = new int[1];
        } else {
            int[] newArray = new int[exams.length + 1];
            System.arraycopy(exams, 0, newArray, 0, exams.length);
            exams = newArray;
        }
        exams[exams.length - 1] = score;
    }

    public double getGPA() {
        if (exams == null) {
            return 0;
        }
        double total = 0.0;
        for (int i = 0; i < exams.length; i++) {
            total += exams[i];
        }
        return total / exams.length;
    }

    @Override
    public String toString() {
        String str = "StudentID: " + studentID + "\tName: "
                + firstName + " " + lastName + "\tGrade: "
                + gradeLevel + "\tGPA: " + getGPA() + "\t" + getExams();
        return str;
    }
    private static int randomNumber(int lower, int upper){
        return (int) (Math.random() * (upper - lower) + lower);
    }
    public int getGradeLevel(){
        return gradeLevel;
    }
    public String getExams(){
        String examList = "Exam Scores: ";
        for (int i = 0; i < exams.length; i++) {
            if(i != exams.length - 1){
                examList += exams[i] + ", ";
            } else {
                examList += exams[i];
            }
        }
        return examList;
    }
    public String playRPS(){
        String[] options = {"rock", "paper", "scissors"};
        String pick = options[randomNumber(0, 3)];
        return pick;
    }
    public String getName(){
        return firstName + " " + lastName;
    }
}
