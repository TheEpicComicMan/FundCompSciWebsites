﻿// Create a new project called UserIDCrypto (where UserID is your User ID).
// Replace everything with the starter code below.  Rename the class name 
// back to the original name which should be UserIDCrypto.
// Don’t forget to put your name in the comments at the top of the program!
// Please do not zip your submission. Only upload the JAVA file.
/**
 * Name    : Migyanka, Anthony
 * User ID : agm8020
 * Lab     : String Lab 4 - Encryption
 *
 * Description of encryption algorithm:
 *
 *
 */
package AGM8020Crypto;

import java.util.Scanner;

public class AGM8020Crypto {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        System.out.println("Welcome to Crypto:");
        int option;
        do {
            System.out.print("Enter 1 to encrypt, 2 to decrypt, 0 to exit: ");
            option = kb.nextInt();

            if (option == 1) {
                encrypt();
            }
            if (option == 2) {
                decrypt();
            }
        } while (option != 0);
    }

    /**
     * Write two methods; encrypt() and decrypt() Use a Scanner object & the
     * method nextLine() to read in a line of text. Document you algorithm in
     * the comments at the top of the program. Your encryption algorithm will be
     * graded on its complexity and your documentation of the algorithm you are
     * using. For example, simply swapping letters or shifting right/left by x
     * number of letters will receive a maximum score of 80%
     */
    private static void encrypt() {
        System.out.println("Enter a string to encrypt:");
        Scanner kb = new Scanner(System.in);
        String str = kb.nextLine();

        String encrypted = "";

        for (int i = 0; i < str.length(); i++) {

            String test = printBinaryForm((int) str.charAt(i));
            encrypted += test;

        }

        String hold = "";

        for (int i = 0; i < encrypted.length(); i++) {
            if (encrypted.charAt(i) == '1') {
                hold += "Kerbal";
            } else if (encrypted.charAt(i) == '0') {
                hold += "SpaceP";
            } else {
                hold += " ";
            }
        }
        encrypted = hold;

        System.out.println(encrypted);

    }

    private static void decrypt() {
        System.out.println("Enter a string to decrypt:");
        Scanner kb = new Scanner(System.in);
        String str = kb.nextLine();

        String binary = "";
        for (int i = 0; i < str.length(); i += 6) {
            if (str.charAt(i) == 'K') {
                binary += "1";
            } else if (str.charAt(i) == 'S') {
                binary += "0";
            } else {
                binary += " ";
            }
        }

        //Integer.parseInt(num, 2)
        int a = 0;
        int b = 7;
        String hold = "";
        for (int i = 0; i < binary.length() / 7; i++) {
            String x = binary.substring(a, b);
            hold += integerfrmbinary(x) + " ";
            a += 7;
            b += 7;

        }
        hold=hold.substring(0, hold.length() - 2);
        
        int numSpace = 0;
        for(int i = 0; i < hold.length(); i++){
            if(hold.charAt(i) == ' '){
                numSpace++;
            }
        }
	String[] numbers = new String[numSpace + 1];
	int index = 0;
	for(int i = 0; i < hold.length; i++){
		if(hold.charAt(i) != ' '){
			numbers[index] += hold.charAt(i);
		} else {
			index++;
		}
	}
	String decrypted = "";
	for(int i = 0; i < numbers.length; i++){
		decrypted+=(int) numbers(i);
	}
	System.out.println(decrypted);

    }

    private static String printBinaryForm(int number) {
        String string = Integer.toBinaryString(number);  //decimal to binary(string)

        return string;

    }

    public static int integerfrmbinary(String str) {
        System.out.print(str);
        return Integer.parseInt(str, 2);
    }
}
// KerbalSpacePSpacePKerbalSpacePSpacePSpacePKerbalKerbalSpacePSpacePKerbalSpacePKerbalKerbalKerbalSpacePKerbalKerbalSpacePSpacePKerbalKerbalSpacePKerbalKerbalSpacePSpacePKerbalKerbalSpacePKerbalKerbalKerbalKerbal
