/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.

 * Anthony Migyanka
 */
package agm8020dice;

import java.util.Scanner;

/**
 *
 * @author agm8020
 */
public class AGM8020Dice {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("How many dice? ");
        int numDice = keyboard.nextInt();
        int[] dice = new int[numDice];
        for(int i = 0; i < numDice; i++){
            System.out.println("How many sides does this dice have? ");
            dice[i] = keyboard.nextInt();
        }
        int maxSum = 0;
        for(int i = 0; i < numDice; i++){
            maxSum += dice[i];
        }
        int[] results = new int[maxSum];
        int numRuns = 1000;
        for(int i = 0; i < numRuns; i++){
            int sum = 0;
            for(int k = 0; k < numDice; k++){
                sum += (int)(Math.random() * dice[k] + 1);
            }
            int spot = sum-1;
            results[spot]++;
        }
        System.out.print("Values:   ");
        for(int j = numDice; j < maxSum + 1; j++){
            System.out.print(String.format("%-10s", (j)));
        }
        System.out.println("");
        System.out.print("Results:  ");
        for(int h = numDice; h < maxSum + 1; h++){
            System.out.format(String.format("%-10s", results[h - 1]));
        }
        System.out.println("");
        System.out.print("Odds:     ");
        for(int j = numDice; j < maxSum + 1; j++){
            float odds = (float) results[j - 1] / numRuns;
            System.out.print(String.format("%-10s", odds));
        }
        System.out.println("");
        
    }
    
}
