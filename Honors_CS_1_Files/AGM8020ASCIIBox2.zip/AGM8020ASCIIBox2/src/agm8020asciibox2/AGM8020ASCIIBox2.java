/*
 * Name    : Last, First
 * User ID : abc1234
 * Lab #   : 0
 */

package agm8020asciibox2;

public class AGM8020ASCIIBox2 {

    public static void main(String[] args) {

        System.out.println("12345678901234567");
        System.out.println("^^^^^^^^^^^^^^^^^");
        System.out.println("H\t\tH");
        System.out.println("H\t\tH");
        System.out.println("H\t\tH");
        System.out.println("H    Coppell    H");
        System.out.println("H\t\tH");
        System.out.println("H\t\tH");
        System.out.println("H\t\tH");
        System.out.println("^^^^^^^^^^^^^^^^^");
        System.out.println("12345678901234567");

    }

}
