/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agm8020arraylistlab1;

/**
 *
 * @author agm8020
 */
import java.util.ArrayList;
import java.util.Arrays;

public class AGM8020ArrayListLab1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // datattype can be class or prinative, for primative, caps
        //on first letter and use full word
        //ArrayList<DATATYPE> name = new ArrayList<>();

        int[] list1 = new int[10];
        ArrayList<Integer> list2 = new ArrayList<>();

        System.out.print(list1.length + "\n" + list2.size() + "\n");

        for (int i = 0; i < list1.length; i++) {
            list1[i] = i * 2;
            list2.add(i * 2);
        }
        list1[5] = 88;
        list2.set(5, 88);

        System.out.println(Arrays.toString(list1));
        System.out.println(list2);

        for (int i = 0; i < list1.length; i++) {
            list2.add(list1[i]);
        }
        for (int i = 0; i < list2.size(); i++) {
            System.out.print(list2.get(i) + " ");
        }

        for (int i = 0; i < list2.size(); i++) {
            if (list2.get(i) % 4 == 0) {
                list2.remove(i);
                i--;
            }
        }
        System.out.println();
        for (int i = 0; i < list2.size(); i++) {
            System.out.print(list2.get(i) + " ");
        }
        int sum = 0;
        System.out.println();
        for (int i = 0; i < list2.size(); i++) {
            sum += list2.get(i);
        }
        System.out.println(sum);

    }

}
