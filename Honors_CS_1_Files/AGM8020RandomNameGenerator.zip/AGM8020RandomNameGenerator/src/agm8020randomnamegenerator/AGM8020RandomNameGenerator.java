/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.

Anthony Migyanka


 */
package agm8020randomnamegenerator;

/**
 *
 * @author agm8020
 */
public class AGM8020RandomNameGenerator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for(int i = 0; i < 100; i++){
            System.out.println(getName());
        }
    }
    private static String getName(){
        String name = "";
        
        // first letter is caps
        name += (char) randomNumber(65, 90);
        
        // rest of first name
        for(int i = 0; i < 8; i++){
            name += (char) randomNumber(97, 122);
        }
        
        // need space between first and last name
        name += " ";
     
        // first letter is caps
        name += (char) randomNumber(65, 90);
        
        // rest of last name
        for(int i = 0; i < 8; i++){
            name += (char) randomNumber(97, 122);
        }
        
        name = nameIsValid(name);
        
        return name;
    }
    private static String nameIsValid(String name){
        int numC = 0;
        String consta = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ";
        String vowel = "aeiouAEIOU";
        for(int i = 0; i < name.length(); i++){
            if(consta.contains(name.charAt(i)+ "")){
                numC++;
            }
            if(numC == 3){
                char testChar;
                    if(name.charAt(i-1) != ' '){
                        testChar = vowel.charAt(randomNumber(0, 4));
                    } else {
                        testChar = vowel.charAt(randomNumber(5, 9));
                    }
                    String name2 = "";
                    for(int a = 0; a < name.length(); a++){
                        if(a != i){
                            name2 += name.charAt(a);
                        } else {
                            name2 += testChar;
                        }
                    }
                    name = name2;
                    numC = 0;
                }
            if(vowel.contains(name.charAt(i)+ "")){
                numC = 0;
            }
        }
        int numV = 0;
        for(int i = 0; i < name.length(); i++){
            if(vowel.contains(name.charAt(i)+ "")){
                numV++;
            }
            if(numV == 3){
                char testChar;
                    if(name.charAt(i-1) != ' '){
                        testChar = consta.charAt(randomNumber(0, 4));
                    } else {
                        testChar = consta.charAt(randomNumber(5, 9));
                    }
                    String name2 = "";
                    for(int a = 0; a < name.length(); a++){
                        if(a != i){
                            name2 += name.charAt(a);
                        } else {
                            name2 += testChar;
                        }
                    }
                    name = name2;
                    numV = 0;
                }
            if(consta.contains(name.charAt(i)+ "")){
                numV = 0;
            }
        }
        return name;
    }
    private static int randomNumber(int lower, int upper){
        return (int) (Math.random() * (upper - lower) + lower);
    }
}
