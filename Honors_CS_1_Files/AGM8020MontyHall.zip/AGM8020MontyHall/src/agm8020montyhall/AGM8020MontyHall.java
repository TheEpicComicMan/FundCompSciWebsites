/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agm8020montyhall;

import java.util.Scanner;

/**
 *
 * @author agm8020
 */
public class AGM8020MontyHall {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter the number of times you want to play: ");
        int times = keyboard.nextInt();
        System.out.println("   " + "Prize" + "   " + "Guess" + "   " + "View" + "   " + "New Guess");
        int win;
        int firstGuess;
        int showDoor;
        int secondGuess = 0;
        int correctswitch = 0;
        int correctnotswitch = 0;
        for (int i = 0; i < times; i++) {
            win = (int) (Math.random() * 3) + 1;

            firstGuess = (int) (Math.random() * 3) + 1;

            showDoor = (int) (Math.random() * 3) + 1;
            while (showDoor == firstGuess) {
                showDoor = (int) (Math.random() * 3) + 1;
            }

            if (firstGuess == win) {
                correctswitch++;
            }
            System.out.println("     " + win + "" + "       " + firstGuess + "" + "      " + showDoor + "" + "         " + secondGuess + "");
        }
        System.out.println("");
        System.out.println("Probability of winning if you switch = " + ((correctswitch / (double) times)));
        System.out.println("Probability of winning if you do not switch = " + (1 -(correctswitch / (double) times)));
    }
}
