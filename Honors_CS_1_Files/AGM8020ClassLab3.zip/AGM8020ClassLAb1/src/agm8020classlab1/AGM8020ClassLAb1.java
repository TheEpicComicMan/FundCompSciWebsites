/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agm8020classlab1;

import java.util.Arrays;

/**
 *
 * @author agm8020
 *
 * Anthony Migyanka
 *
 *
 */
public class AGM8020ClassLAb1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Student[] student = new Student[4000];
        Student[] topStudent = new Student[4];

        int num9th = 0;
        int num10th = 0;
        int num11th = 0;
        int num12th = 0;

        for (int i = 0; i < student.length; i++) {
            student[i] = new Student();
            int num = randomNumber(4, 8);
            for (int a = 0; a < num; a++) {
                student[i].takeExam();
            }
            switch (student[i].getGradeLevel()) {
                case 9:
                    num9th++;
                    break;
                case 10:
                    num10th++;
                    break;
                case 11:
                    num11th++;
                    break;
                case 12:
                    num12th++;
                    break;
                default:
                    break;
            }
        }
        Student[] students9 = new Student[num9th];
        Student[] students10 = new Student[num10th];
        Student[] students11 = new Student[num11th];
        Student[] students12 = new Student[num12th];

        int used9 = 0;
        int used10 = 0;
        int used11 = 0;
        int used12 = 0;

        for (int i = 0; i < student.length; i++) {
            switch (student[i].getGradeLevel()) {
                case 9:
                    students9[used9] = student[i];
                    used9++;
                    break;
                case 10:
                    students10[used10] = student[i];
                    used10++;
                    break;
                case 11:
                    students11[used11] = student[i];
                    used11++;
                    break;
                case 12:
                    students12[used12] = student[i];
                    used12++;
                    break;
                default:
                    break;
            }
        }
        
        double maxGpa = 0.0;
        for (int i = 0; i < students9.length; i++) {
            if (students9[i].getGPA() > maxGpa) {
                topStudent[0] = students9[i];
                maxGpa = students9[i].getGPA();
            }
        }
        maxGpa = 0.0;
        for (int i = 0; i < students10.length; i++) {
            if (students10[i].getGPA() > maxGpa) {
                topStudent[1] = students10[i];
                maxGpa = students10[i].getGPA();
            }
        }
        maxGpa = 0.0;
        for (int i = 0; i < students11.length; i++) {
            if (students11[i].getGPA() > maxGpa) {
                topStudent[2] = students11[i];
                maxGpa = students11[i].getGPA();
            }
        }
        maxGpa = 0.0;
        for (int i = 0; i < students12.length; i++) {
            if (students12[i].getGPA() > maxGpa) {
                topStudent[3] = students12[i];
                maxGpa = students12[i].getGPA();
            }
        }
        for (int i = 0; i < 4; i++) {
            System.out.println(topStudent[i].toString());
        }

    }

    private static int randomNumber(int lower, int upper) {
        return (int) (Math.random() * (upper - lower) + lower);
    }

}
