/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agm8020pi;

/**
 *
 * @author agm8020
 */
public class AGM8020PI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double hits = 0;
        int numThrows = 100000000;
        int hit = 0;
        for (int i = 0; i < numThrows; i++){
            double xValue = Math.random() * 2 - 1;
            double yValue = Math.random() * 2 - 1;
            double dis = Math.sqrt(Math.pow(xValue, 2) + Math.pow(yValue, 2));
            if(dis < 1){
               hits++; 
            }
        }
        double pi = hits / numThrows * 4;
        System.out.println(pi);
    }
    
}
