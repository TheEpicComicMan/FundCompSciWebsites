/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.

Anthony Migyanaka

 */
package agm8020arraylab2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author agm8020
 */
public class AGM8020ArrayLab2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //part 1
        System.out.println("Part 1: ");
        int[] nums = {2, 9, 4, 7, 6, 5, 8, 3, 10, 1};
        for (int i = 0; i < nums.length; i++) {
            if (i != nums.length - 1) {
                System.out.print(nums[i] + " - ");
            } else {
                System.out.println(nums[i]);
            }
        }
        //part 2
        System.out.println("----------------------------");
        System.out.println("Part 2: ");
        int last = nums[nums.length - 1];
        for (int i = nums.length - 1; i > 0; i--) {
            nums[i] = nums[i - 1];
        }
        nums[0] = last;
        for (int i = 0; i < nums.length; i++) {
            if (i != nums.length - 1) {
                System.out.print(nums[i] + " - ");
            } else {
                System.out.println(nums[i]);
            }
        }
        //part 3
        System.out.println("----------------------------");
        System.out.println("Part 3: ");
        int[] nums2 = {2, 9, 4, 7, 6, 5, 8, 3, 10, 1};
        Scanner k = new Scanner(System.in);
        System.out.print("Enter the number of shifts: ");
        int shift = k.nextInt();
        
        for (int a = 0; a < shift; a++) {
            int last2 = nums2[nums2.length - 1];
            for (int i = nums2.length - 1; i > 0; i--){
                nums2[i] = nums2[i - 1];
            }
            nums2[0] = last2;
        }
        for (int i = 0; i < nums2.length; i++) {
            if (i != nums2.length - 1) {
                System.out.print(nums2[i] + " - ");
            } else {
                System.out.println(nums2[i]);
            }
        }
    }

}
