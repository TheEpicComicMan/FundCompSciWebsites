/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.

    Anthony Migyanka


 */
package agm8020stringlab2;

/**
 *
 * @author agm8020
 */
public class AGM8020StringLab2 {

    /**
     * @param args the command line arguments
     */
    
public static void main(String[] args) {
    System.out.println(isComplex("Erin M Haggens", "Password#123")); //true
    System.out.println(isComplex("Erin M Haggens", "erinPass#1"));   //false
    System.out.println(isComplex("Erin M Haggens", "Pass#12"));      //false
    System.out.println(isComplex("Erin M Haggens", "password#123")); //false
    System.out.println(isComplex("Erin M Haggens", "PASSWORD#123")); //false
    System.out.println(isComplex("Erin M Haggens", "Password#"));    //false
    System.out.println(isComplex("Erin M Haggens", "Password123"));  //false
}

private static boolean isComplex(String displayName, String password) {

    String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    String lower = "abcdefghijklmnopqrstuvwxyz";
    String digit = "0123456789";
    String nonAlpha = "~!@#$%^&*_-+=`|\\{(){}[]:;\"'<>,.?/";
    
    
    
    // truth vars
    boolean length = password.length() > 8;
    boolean containsUp = false;
    boolean containsDown = false;
    boolean containsSpecial = false;
    boolean containsDigit = false;
    
    String[] tokens = displayName.split(" ");
    for(int i = 0; i < tokens.length; i++){
        if(password.length() > 2 && password.toLowerCase().contains(tokens[i].toLowerCase())){
            return false;
        }
    }
    for(int i = 0; i < password.length(); i++){
        // upper
        for(int a = 0; a < upper.length(); a++){
            if(upper.contains(password.charAt(i) + "")){
                containsUp = true;
            }
        }
        // lower
        for(int a = 0; a < lower.length(); a++){
            if(lower.contains(password.charAt(i) + "")){
                containsDown = true;
            }
        }
        // special
        for(int a = 0; a < digit.length(); a++){
            if(digit.contains(password.charAt(i) + "")){
                containsDigit = true;
            }
        }
        // upper
        for(int a = 0; a < nonAlpha.length(); a++){
            if(nonAlpha.contains(password.charAt(i) + "")){
                containsSpecial = true;
            }
        }
    }
    
    
   
    return length && containsUp && containsDown && containsSpecial && containsDigit;
}
}