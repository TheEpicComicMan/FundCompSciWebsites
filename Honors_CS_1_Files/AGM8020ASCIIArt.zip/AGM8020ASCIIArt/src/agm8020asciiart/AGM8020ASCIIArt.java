/*
 * Name    : Last, First
 * User ID : abc1234
 * Lab #   : 0
 */

package agm8020asciiart;

public class AGM8020ASCIIArt {

    public static void main(String[] args) {

        System.out.println("A-10 Thunderbolt II                                                                ");
        System.out.println("                          []                         []                            ");
        System.out.println("                          ||   ___     ___     ___   ||                            ");
        System.out.println("                          ||  /   \\   /| |\\   /   \\  ||                            ");
        System.out.println("                          || |  O  |__|| ||__|  O  | ||                            ");
        System.out.println("                          ||  \\___/--/^^^^^\\--\\___/  ||                            ");
        System.out.println("                      __  ||________|       |________||  __                        ");
        System.out.println("   .-----------------/  \\-++--------|   .   |--------++-/  \\-----------------.     ");
        System.out.println("  /.---------________|  |___________\\__(*)__/___________|  |________---------.\\    ");
        System.out.println("            |    |   '$$'   |                       |   '$$'   |    |              ");
        System.out.println("           (o)  (o)        (o)                     (o)        (o)  (o)             "); 

    }

}
