/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.

Anthony Migyanka

 */
package agm8020arraylab;

import java.util.Arrays;

/**
 *
 * @author agm8020
 */
public class AGM8020ArrayLab {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //part 1
        System.out.println("-------------------------------");
        System.out.println("Part 1:");
        int[] odd = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19};
        for(int i = 0; i < odd.length; i++){
            System.out.println(odd[i]);
        }
        //part 2
        System.out.println("-------------------------------");
        System.out.println("Part 2:");
        String[] words ={"hi", "hello", "space", "NASA", "Kerbal", "Space", "Program", "bye"};
        for(int i = 0; i < words.length; i++){
            System.out.println(words[i]);
        }
        //part 3
        System.out.println("-------------------------------");
        System.out.println("Part 3:");
        for(int i = 0; i < 10; i++){
            int a = (int)(Math.random() * 8);
            System.out.println(words[a]);
        }
        //part 4
        System.out.println("-------------------------------");
        System.out.println("Part 4:");
        int[] array = new int[100];
        for(int i = 0; i < array.length; i++){
            array[i] = (int)(Math.random() * 901) + 100;
        }
        int sum = 0;
        for(int i = 0; i < array.length; i++){
            sum += array[i];
        }
        System.out.println(sum / 100);
        Arrays.sort(array);
        for(int i = 0; i < array.length; i++){
            System.out.print(array[i] + " ");
        }
    }
    
}
