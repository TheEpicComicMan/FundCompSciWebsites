/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agm8020tictactoe;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author agm8020
 */
public class AGM8020TicTacToe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        String filename = "game.txt";
        Scanner readFile = new Scanner(new File(filename));
        int box1 = readFile.nextInt();
        int box2 = readFile.nextInt();
        int box3 = readFile.nextInt();
        int box4 = readFile.nextInt();
        int box5 = readFile.nextInt();
        int box6 = readFile.nextInt();
        int box7 = readFile.nextInt();
        int box8 = readFile.nextInt();
        int box9 = readFile.nextInt();
        System.out.println(box1 +" "+ box2 +" "+ box3);
        System.out.println(box4 +" "+ box5 +" "+ box6);
        System.out.println(box7 +" "+ box8 +" "+ box9);
        //123
        if(box1 == box2 && box2 == box3){
            if(box1 == 1){
                System.out.println("Player 1 won!");
            } else {
                System.out.println("Player 2 won!");
            }
        }else if(box4 == box5 && box5 == box6){
            if(box4 == 1){
                System.out.println("Player 1 won!");
            } else {
                System.out.println("Player 2 won!");
            }
        }else if(box7 == box8 && box8 == box9){
            if(box7 == 1){
                System.out.println("Player 1 won!");
            } else {
                System.out.println("Player 2 won!");
            }
        }else if(box1 == box5 && box5 == box9){
            if(box1 == 1){
                System.out.println("Player 1 won!");
            } else {
                System.out.println("Player 2 won!");
            }
        }else if(box7 == box5 && box5 == box3){
            if(box7 == 1){
                System.out.println("Player 1 won!");
            } else {
                System.out.println("Player 2 won!");
            }
        }else if(box1 == box4 && box4 == box7){
            if(box1 == 1){
                System.out.println("Player 1 won!");
            } else {
                System.out.println("Player 2 won!");
            }
        }else if(box2 == box5 && box5 == box8){
            if(box1 == 2){
                System.out.println("Player 1 won!");
            } else {
                System.out.println("Player 2 won!");
            }
        }else if(box3 == box6 && box6 == box9){
            if(box3 == 1){
                System.out.println("Player 1 won!");
            } else {
                System.out.println("Player 2 won!");
            }
        } else {
            System.out.println("The players tied!");
        }  
    }
    
}
