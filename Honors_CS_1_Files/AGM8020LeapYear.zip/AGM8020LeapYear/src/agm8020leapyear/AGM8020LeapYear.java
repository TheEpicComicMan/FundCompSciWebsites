/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agm8020leapyear;

import java.util.Scanner;

/**
 *
 * @author agm8020
 */
public class AGM8020LeapYear {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner keyboard = new Scanner (System.in);
        System.out.print("Enter a year: ");
        int year = keyboard.nextInt();
        
        if(year % 4 == 0){
            if(year % 100 == 0){
                if(year % 400 == 0){
                    System.out.println("This is a leap year!");
                } else {
                    System.out.println("This is not a leap year!");
                }
            } else {
                System.out.println("This is a leap year!");
            }
        } else {
            System.out.println("This is not a leap year!");
        }
                
    }
    
}
