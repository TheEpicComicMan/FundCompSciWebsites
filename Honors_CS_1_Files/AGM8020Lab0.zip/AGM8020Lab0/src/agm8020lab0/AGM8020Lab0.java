/*
 * Name    : Last, First
 * User ID : abc1234
 * Lab #   : 0
 */

package agm8020lab0;

public class AGM8020Lab0 {

    public static void main(String[] args) {

        System.out.println("Hello World");

    }

}
