/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.


Anthony Migyanka
 */
package agm8020looplab;

import java.util.Scanner;

/**
 *
 * @author agm8020
 */
public class AGM8020LoopLab {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //part 1
        System.out.println("Part 1:");
        for (int i = 1; i < 11; i++) {
            System.out.print(i + ", ");
        }

        //seperation
        System.out.println("");
        System.out.println("");
        System.out.println("Part 2:");

        //part 2
        for (int i = 10; i > -1; i--) {
            System.out.print(i + ", ");
        }

        //seperation
        System.out.println("");
        System.out.println("");
        System.out.println("Part 3:");

        //part 3
        int[] nums = new int[9];
        for (int i = 0; i < nums.length; i++) {
            nums[i] = i + 1;
        }
        for (int a = 1; a < 10; a++) {
            for (int i = 0; i < nums.length; i++) {
                int spot = nums[i];
                int row = a;
                System.out.print(spot * row + "\t");
            }
            System.out.println("");
        }
        //part 4
        System.out.println("");
        System.out.println("");
        System.out.println("Part 4:");

        int num = (int) (Math.random() * 100) + 1;
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Guess a number between 1 and 100: ");
        int guess = keyboard.nextInt();
        int guessNum = 1;
        while (guess != num) {
            guessNum++;
            if (guess > num) {
                System.out.println("Lower");
            } else if (guess < num) {
                System.out.println("Higher");
            }
            System.out.println("Guess a number between 1 and 100: ");
            guess = keyboard.nextInt();
        }
        System.out.println("Congratulations, it only took you " + guessNum + " to guess it!");
    }

}
