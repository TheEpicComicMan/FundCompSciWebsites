/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.

    Anthony Migyanka


 */
package agm8020stringlab1;

import java.util.Arrays;

/**
 *
 * @author agm8020
 */
public class AGM8020StringLab1 {

    /**
     * @param args the command line arguments
     */
        // replace the main method and everything below it with the following

    public static void main(String[] args) {
        
        String[] list = {"Coppell, TX", "Dallas, TX", "Tulsa, OK", "Plano, TX",
            "Denver, CO", "Irving, TX", "Orlando, FL", "Austin, TX",
            "New York, NY", "Seattle, WA", "Houston, TX"};
        
        String[] cities = findCities(list, "TX");
        for (int i = 0; i < cities.length; i++) {
            System.out.print(cities[i] + "\t");
        }
        System.out.println("");
    }
    
    public static String[] findCities(String[] list, String state) {
        int len = 0;
        for(int i = 0; i < list.length; i++){
            if(list[i].contains(state)){
                len++;
            }
        }
        int place = 0;
        String[] result = new String[len];
        for(int i = 0; i < list.length; i++){
            if(list[i].contains(state)){
                result[place] = list[i];
                place++;
            }
        }
        for(int i = 0; i < len; i++){
            result[i] = result[i].substring(0, result[i].length() - 4);
        }
        return result;
    }

    
}
