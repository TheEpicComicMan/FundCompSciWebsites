/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agm8020classlab1;

/**
 *
 * @author agm8020
 */
public class AGM8020ClassLAb1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Student anthony = new Student ("Anthony", "Migyanka", 38020, 9);
        anthony.takeExam();
        anthony.takeExam();
        String printable = anthony.toString();
        System.out.println(printable);
        
        
        Student rithik = new Student ("Rithik", "Chennupati", 36440, 10);
        rithik.takeExam();
        rithik.takeExam();
        printable = rithik.toString();
        System.out.println(printable);
    }
    
}