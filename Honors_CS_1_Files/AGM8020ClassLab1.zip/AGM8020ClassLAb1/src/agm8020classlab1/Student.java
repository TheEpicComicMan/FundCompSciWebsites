public class Student {

    private String firstName;
    private String lastName;
    private int studentID;
    private int gradeLevel;
    private int[] exams;

    public Student(String first, String last, int id, int grade) {
        firstName = first;
        lastName = last;
        studentID = id;
        gradeLevel = grade;
    }

    public void takeExam() {
        int score = (int) (Math.random() * 31 + 70);
        if (exams == null) {
            exams = new int[1];
        } else {
            int[] newArray = new int[exams.length + 1];
            System.arraycopy(exams, 0, newArray, 0, exams.length);
            exams = newArray;
        }
        exams[exams.length - 1] = score;
    }

    public double getGPA() {
        if (exams == null) {
            return 0;
        }
        double total = 0.0;
        for (int i = 0; i < exams.length; i++) {
            total += exams[i];
        }
        return total / exams.length;
    }

    @Override
    public String toString() {
        String str = "StudentID: " + studentID + "  Name: "
                + firstName + " " + lastName + "\tGrade: "
                + gradeLevel + "\tGPA: " + getGPA();
        return str;
    }
}