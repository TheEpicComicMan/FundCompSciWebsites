/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agm8020scanner;

/**
 *
 * @author agm8020
 */
import java.util.Scanner;
public class AGM8020Scanner {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter recipient's Name: ");
        String recname = keyboard.nextLine();
        System.out.print("Enter recipient's Address: ");
        String recadd = keyboard.nextLine();
        System.out.print("Enter recipient's City: ");
        String reccity = keyboard.nextLine();
        System.out.print("Enter recipient's State '2 letters': ");
        String recstate = keyboard.nextLine();
        System.out.print("Enter recipient's Zip code: ");
        String reccode = keyboard.nextLine();
        System.out.println("");
        System.out.print("Enter sender's Name: ");
        String senname = keyboard.nextLine();
        System.out.print("Enter sender's Address: ");
        String senadd = keyboard.nextLine();
        System.out.print("Enter sender's City: ");
        String sencity = keyboard.nextLine();
        System.out.print("Enter sender's State '2 letters': ");
        String senstate = keyboard.nextLine();
        System.out.print("Enter sender's Zip code: ");
        String sencode = keyboard.nextLine();
        System.out.println("");
        System.out.println("");
        System.out.println(senname);
        System.out.println(senadd);
        System.out.println(sencity + ", " + senstate + " " + sencode);
        System.out.println("");
        System.out.println("");
        System.out.println("                   " + recname);
        System.out.println("                   " + recadd);
        System.out.println("                   " + reccity + ", " + recstate + " " + reccode);
    }
    
}
