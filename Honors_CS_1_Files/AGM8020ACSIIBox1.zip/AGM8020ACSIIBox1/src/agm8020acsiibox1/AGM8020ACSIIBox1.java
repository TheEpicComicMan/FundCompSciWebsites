/*
 * Name    : Last, First
 * User ID : abc1234
 * Lab #   : 0
 */

package agm8020acsiibox1;

public class AGM8020ACSIIBox1 {

    public static void main(String[] args) {

        System.out.println("AAAAAAAAAAAAAAAAAAAA");
        System.out.println("BBBBBBBBBBBBBBBBBBBB");
        System.out.println("CCCCCCCCCCCCCCCCCCCC");
        
        System.out.println("--------------------");
        
        System.out.println("11111111111111111111");
        System.out.println("22222222222222222222");
        System.out.println("33333333333333333333");

    }

}
