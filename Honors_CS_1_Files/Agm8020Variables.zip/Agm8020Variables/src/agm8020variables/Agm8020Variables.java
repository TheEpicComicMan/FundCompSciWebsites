/*
 * Name    : Last, First
 * User ID : abc1234
 * Lab #   : 0
 */

package agm8020variables;

public class Agm8020Variables {

    public static void main(String[] args) {

        byte byteNumber = 99;
        System.out.println("byteNumber =  " + byteNumber);
        
        short shortNumber = 99;
        System.out.println("shortNumber =  " + shortNumber);
        
        int intNumber = 99;
        System.out.println("intNumber =  " + intNumber);
        
        long longNumber = 99;
        System.out.println("longNumber =  " + longNumber);
        
        float floatNumber = (float) .99;
        System.out.println("floatNumber =  " + floatNumber);
        
        double doubleNumber = 99;
        System.out.println("doubleNumber =  " + doubleNumber);
        
        char charwrd = 'A';
        System.out.println("charwrd =  " + charwrd);
       
        boolean boolNumber = true;
        System.out.println("boolNumber =  " + boolNumber);

    }

}
